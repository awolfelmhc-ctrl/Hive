
# Hive Web (Click-to-move) — Ladybug & Mosquito

Coordinate-free Hive you can play in the browser: click a piece to highlight **legal destinations**, then click a target hex to move. For placing, select a piece (e.g., Queen) and click a highlighted empty hex. Expansions **Ladybug** and **Mosquito** are supported.

## Quick start

```bash
cd hive_web_click_game
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://localhost:5000

## Features
- Click-to-select top piece; legal moves are shown.
- Place mode: choose a piece; legal placement hexes are shown for your turn.
- Turn-based engine enforces **One Hive** and **Freedom-to-Move** (sliding/gates).
- Ladybug: two steps on top then one down (cannot end on top; cannot travel outside on ground). Mosquito: copies adjacent **top** piece at start of move; behaves as Beetle when on top.
- Optional browser **notifications** when it becomes your turn.

## Endpoints
- `POST /api/start` → `{code, color}`
- `POST /api/join` → `{code, color}`
- `POST /api/state` → `{cells:[{q,r,stack:[{color,ptype}]}], turn, status}`
- `POST /api/legal_moves` → `{moves:[{q,r}]}` (only for your piece on your turn)
- `POST /api/legal_placements` → `{spots:[{q,r}]}`
- `POST /api/place` → place selected piece
- `POST /api/move` → move selected piece
- `POST /api/expansions` → toggle ON/OFF

## Notes
- Axial coordinates (q,r). Pointy-top hex geometry.
- Default set: base + Ladybug + Mosquito. Tournament variants (like “no Queen first”) are **not** enforced.

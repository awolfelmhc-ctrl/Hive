
(function(){
  const playerIdKey = 'hive_click_player_id';
  let playerId = localStorage.getItem(playerIdKey);
  if(!playerId){ playerId = Math.random().toString(36).slice(2,10)+Math.random().toString(36).slice(2,10); localStorage.setItem(playerIdKey, playerId); }
  let code = localStorage.getItem('hive_click_code') || '';
  let color = localStorage.getItem('hive_click_color') || '';

  const el = (id)=>document.getElementById(id);
  const toast = (msg)=>{ const t=el('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'), 2000); };
  const hint = (msg)=>{ el('hint').textContent = msg || ''; };

  const canvas = el('boardCanvas');
  const ctx = canvas.getContext('2d');
  const size = 28; // hex radius
  let state = { cells: [], turn: 'W', status: 'SETUP' };
  let you = 'W';
  let selected = null; // {q,r}
  let legalMoves = []; // [{q,r}]
  let placementSpots = []; // [{q,r}]
  let placeMode = false; // click an empty spot to place selected piece

  const SQRT3 = Math.sqrt(3);
  const toPixel = (q,r, cx, cy)=>({
    x: cx + size * (SQRT3 * q + SQRT3/2 * r),
    y: cy + size * (1.5 * r)
  });

  function computeCenter(){
    if(!state.cells.length){ return {cx: canvas.width/2, cy: canvas.height/2}; }
    const qs = state.cells.map(c=>c.q), rs = state.cells.map(c=>c.r);
    const minq = Math.min(...qs), maxq=Math.max(...qs), minr=Math.min(...rs), maxr=Math.max(...rs);
    // center hive roughly
    return {cx: canvas.width/2 - ( (maxq+minq)/2 * SQRT3 * size ), cy: canvas.height/2 - ( (maxr+minr)/2 * 1.5 * size )};
  }

  function drawHex(x,y, r, fill, stroke){
    ctx.beginPath();
    for(let i=0;i<6;i++){
      const a = Math.PI/180 * (60*i - 30); // pointy-top
      const px = x + r * Math.cos(a);
      const py = y + r * Math.sin(a);
      if(i===0) ctx.moveTo(px,py); else ctx.lineTo(px,py);
    }
    ctx.closePath();
    if(fill){ ctx.fillStyle = fill; ctx.fill(); }
    ctx.lineWidth = 1.5; ctx.strokeStyle = stroke || '#888'; ctx.stroke();
  }

  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // background grid only for visible spots (cells + legal moves + placements)
    const {cx, cy} = computeCenter();
    const occupied = new Set(state.cells.map(c=>`${c.q},${c.r}`));

    // draw occupied cells
    for(const cell of state.cells){
      const p = toPixel(cell.q, cell.r, cx, cy);
      drawHex(p.x, p.y, size, '#222', '#eee');
      // stack top marker and letters
      const top = cell.stack[cell.stack.length-1];
      ctx.fillStyle = top.color==='W' ? '#fff' : '#ffd54f';
      ctx.font = 'bold 16px system-ui';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(top.ptype, p.x, p.y);
      // stack height badge
      if(cell.stack.length>1){
        ctx.fillStyle = '#0af';
        ctx.fillRect(p.x+size-16, p.y-size+4, 12, 16);
        ctx.fillStyle = '#fff';
        ctx.font = '12px system-ui';
        ctx.fillText(String(cell.stack.length), p.x+size-10, p.y-size+12);
      }
      // selection ring
      if(selected && selected.q===cell.q && selected.r===cell.r){
        drawHex(p.x, p.y, size+2, null, '#0af');
      }
    }

    // draw legal move targets
    for(const m of legalMoves){
      const p = toPixel(m.q, m.r, cx, cy);
      drawHex(p.x, p.y, size, 'rgba(0,160,255,0.25)', '#0af');
    }

    // draw placement spots
    for(const s of placementSpots){
      const p = toPixel(s.q, s.r, cx, cy);
      drawHex(p.x, p.y, size, 'rgba(0,200,0,0.2)', '#2e7d32');
    }

    // header
    ctx.fillStyle = '#fff';
    ctx.font = '14px system-ui';
    ctx.textAlign = 'left';
    ctx.fillText(`Status: ${state.status} | Turn: ${state.turn==='W'?'White':'Black'} | You: ${you==='W'?'White':'Black'}`, 10, 16);
  }

  function hitTest(x,y){
    // brute-force: check center distance to hex centers
    const {cx, cy} = computeCenter();
    const items = [];
    const seen = new Set();
    const all = [];
    state.cells.forEach(c=>all.push({q:c.q,r:c.r,type:'occupied'}));
    legalMoves.forEach(m=>all.push({q:m.q,r:m.r,type:'move'}));
    placementSpots.forEach(s=>all.push({q:s.q,r:s.r,type:'place'}));
    for(const it of all){
      const key = `${it.q},${it.r},${it.type}`;
      if(seen.has(key)) continue; seen.add(key);
      const p = toPixel(it.q, it.r, cx, cy);
      const dx = x - p.x, dy = y - p.y; const d = Math.sqrt(dx*dx+dy*dy);
      if(d <= size*0.95){ items.push(Object.assign({x:p.x,y:p.y}, it)); }
    }
    // prefer move/place over occupied to make clicks intuitive
    items.sort((a,b)=>{
      const order = {'move':0,'place':1,'occupied':2};
      return order[a.type]-order[b.type];
    });
    return items[0]||null;
  }

  async function api(path, payload){
    const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(Object.assign({}, payload, {playerId}))});
    if(!res.ok) throw new Error(await res.text());
    return res.json();
  }

  async function refresh(){
    if(!code) return toast('Start or join a game first');
    const data = await api('/api/state',{});
    state = data.state; you = data.you;
    draw();
  }

  async function start(){
    const data = await api('/api/start',{});
    code = data.code; color = data.color;
    localStorage.setItem('hive_click_code', code);
    localStorage.setItem('hive_click_color', color);
    setSessionInfo();
    await refresh();
    toast('Game started. Share your code.');
  }

  async function join(){
    const j = el('joinCode').value.trim();
    if(!j) return toast('Enter a join code');
    const data = await api('/api/join',{code:j});
    code = data.code; color = data.color;
    localStorage.setItem('hive_click_code', code);
    localStorage.setItem('hive_click_color', color);
    setSessionInfo();
    await refresh();
    toast('Joined game.');
  }

  function setSessionInfo(){
    el('sessionInfo').textContent = code ? `Code: ${code}  |  You are ${color==='W'?'White':'Black'}` : 'No game yet. Start or join a game.';
    el('joinCode').value = code;
  }

  async function setName(){
    const name = el('nameInput').value.trim();
    if(!name) return toast('Enter a name');
    try{ await api('/api/set_name',{name}); toast('Name saved.'); }catch(e){ toast(e.message); }
  }

  async function toggleExp(){
    const flag = el('expansionsToggle').checked ? 'ON' : 'OFF';
    try{ await api('/api/expansions',{flag}); toast('Expansions '+flag); }catch(e){ toast(e.message); }
  }

  async function showPlacements(){
    if(!code) return toast('Start or join a game first');
    placementSpots = (await api('/api/legal_placements',{})).spots;
    placeMode = false;
    legalMoves = [];
    selected = null;
    hint('Select a spot (green) and then click "Place selected piece"');
    draw();
  }

  async function onCanvasClick(ev){
    const rect = canvas.getBoundingClientRect();
    const x = ev.clientX - rect.left; const y = ev.clientY - rect.top;
    const hit = hitTest(x,y);
    if(!hit){ selected = null; legalMoves = []; hint(''); draw(); return; }

    if(hit.type==='move'){
      // perform move
      const to = {q: hit.q, r: hit.r};
      const from = selected;
      try{
        const data = await api('/api/move',{from_q: from.q, from_r: from.r, to_q: to.q, to_r: to.r});
        state = data.state; legalMoves=[]; selected=null; placementSpots=[]; draw();
      }catch(e){ toast(e.message); }
      return;
    }

    if(hit.type==='place'){
      // set selected spot for placing
      selected = {q: hit.q, r: hit.r}; legalMoves=[]; draw(); hint('Click "Place selected piece" to place.'); return;
    }

    // occupied: select top piece and show moves
    selected = {q: hit.q, r: hit.r}; placementSpots=[]; hint('');
    try{
      legalMoves = (await api('/api/legal_moves',{q:selected.q, r:selected.r})).moves;
      if(!legalMoves.length){ hint('No legal moves (check turn, ownership, one-hive, or sliding).'); }
    }catch(e){ legalMoves=[]; hint(e.message); }
    draw();
  }

  async function placeSelected(){
    if(!selected) return toast('Pick a green spot first');
    const piece = el('pieceSelect').value;
    try{
      const data = await api('/api/place',{piece, q: selected.q, r: selected.r});
      state = data.state; selected=null; placementSpots=[]; legalMoves=[]; draw();
    }catch(e){ toast(e.message); }
  }

  // Notifications when it's your turn
  let notifyEnabled = false; let lastTurn = null; let pollTimer = null;
  async function toggleNotify(){
    notifyEnabled = el('notifyToggle').checked;
    if(notifyEnabled && Notification && Notification.permission!=='granted'){
      try{ await Notification.requestPermission(); }catch{}
    }
    if(notifyEnabled){ startPolling(); } else { stopPolling(); }
  }
  function startPolling(){ if(pollTimer) return; pollTimer = setInterval(async ()=>{
    try{ const data = await api('/api/state',{}); state=data.state; draw(); if(lastTurn!==state.turn && state.turn===you){
      lastTurn = state.turn; if(Notification && Notification.permission==='granted'){ new Notification('Hive','It's your turn!'); } else { toast("It's your turn!"); }
    } else { lastTurn = state.turn; }
    }catch(e){}
  }, 4000); }
  function stopPolling(){ if(pollTimer){ clearInterval(pollTimer); pollTimer=null; } }

  // Wire up
  canvas.addEventListener('click', onCanvasClick);
  el('startBtn').addEventListener('click', start);
  el('joinBtn').addEventListener('click', join);
  el('refreshBtn').addEventListener('click', refresh);
  el('piecesBtn').addEventListener('click', async ()=>{ const data = await api('/api/pieces',{}).catch(e=>toast(e.message)); if(data){ const parts = Object.entries(data.pieces).map(([k,v])=>`${k}:${v}`).join(', '); el('piecesView').textContent = 'Remaining: '+parts; }});
  el('showPlacementsBtn').addEventListener('click', showPlacements);
  el('placeModeBtn').addEventListener('click', placeSelected);
  el('setNameBtn').addEventListener('click', setName);
  el('expansionsToggle').addEventListener('change', toggleExp);
  el('notifyToggle').addEventListener('change', toggleNotify);


async function startAI(){
  const level = el('aiLevel').value;
  const human = el('humanColor').value;
  const data = await api('/api/start_ai',{level, human});
  code = data.code; color = data.color;
  localStorage.setItem('hive_click_code', code);
  localStorage.setItem('hive_click_color', color);
  setSessionInfo();
  await refresh();
  toast(`Started vs AI (${level}).`);
}

  setSessionInfo(); draw();
})();


import os
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv

from game.model import PieceType, Color
from game.engine import Game
from game.ai import HiveAI, Action

load_dotenv()
app = Flask(__name__)

GAMES = {}  # code -> Game
PLAYERS = {}  # playerId -> (code, color)
NAMES = {}  # playerId -> display name


from game.ai import HiveAI, Action

AI_PLAYERS = {}  # code -> {'color': Color, 'level': str}

def ai_loop(code):
    """If it's AI's turn, let AI play one action (place or move)."""
    game = GAMES[code]
    ai = AI_PLAYERS.get(code)
    if not ai or game.status == 'ENDED':
        return
    if game.turn != ai['color']:
        return
    bot = HiveAI(ai['level'])
    act = bot.choose_action(game, ai['color'])
    if not act:
        return
    # Apply the chosen action
    from .game.model import PieceType
    try:
        if act.kind == 'place':
            game.place(ai['color'], PieceType(act.detail['ptype']), (act.detail['q'], act.detail['r']))
        else:
            game.move(ai['color'], (act.detail['from_q'], act.detail['from_r']), (act.detail['to_q'], act.detail['to_r']))
    except Exception:
        return

@app.post('/api/start_ai')
def api_start_ai():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    human_color_str = (payload or {}).get('human','W').upper()
    level = (payload or {}).get('level','medium').lower()
    code = Game.new_code()
    game = Game(expansions=True)
    GAMES[code] = game
    human_color = Color.WHITE if human_color_str=='W' else Color.BLACK
    ai_color = Color.BLACK if human_color==Color.WHITE else Color.WHITE
    game.assign_player(human_color, playerId)
    PLAYERS[playerId] = (code, human_color)
    AI_PLAYERS[code] = {'color': ai_color, 'level': level}
    # If AI goes first, play immediately
    ai_loop(code)
    return jsonify({'ok':True,'code':code,'color':human_color.value, 'ai_color':ai_color.value, 'level':level})


ABBR_TO_TYPE = {
    'Q': PieceType.QUEEN,
    'B': PieceType.BEETLE,
    'S': PieceType.SPIDER,
    'G': PieceType.GRASSHOPPER,
    'A': PieceType.ANT,
    'L': PieceType.LADYBUG,
    'M': PieceType.MOSQUITO,
}

@app.route('/')
def index():
    return render_template('index.html')

# --- JSON API ---

def require_player(payload):
    playerId = (payload or {}).get('playerId')
    if not playerId:
        return None, ('Missing playerId', 400)
    return playerId, None

@app.post('/api/start')
def api_start():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code = Game.new_code()
    game = Game(expansions=True)
    GAMES[code] = game
    color = Color.WHITE if game.players[Color.WHITE] is None else Color.BLACK
    game.assign_player(color, playerId)
    PLAYERS[playerId] = (code, color)
    return jsonify({'ok':True,'code':code,'color':color.value})

@app.post('/api/join')
def api_join():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code = (payload or {}).get('code','').upper()
    if code not in GAMES:
        return ('Invalid code', 400)
    game = GAMES[code]
    # choose available color
    color = None
    if game.players[Color.WHITE] is None:
        color = Color.WHITE
    elif game.players[Color.BLACK] is None:
        color = Color.BLACK
    else:
        return ('Game already has two players', 400)
    game.assign_player(color, playerId)
    PLAYERS[playerId] = (code, color)
    return jsonify({'ok':True,'code':code,'color':color.value})

@app.post('/api/state')
def api_state():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    return jsonify({'ok':True, 'state': game.state(), 'you': color.value})

@app.post('/api/legal_moves')
def api_legal_moves():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    try:
        q = int((payload or {}).get('q'))
        r = int((payload or {}).get('r'))
    except Exception:
        return ('Invalid coordinates', 400)
    moves = [{'q':x,'r':y} for (x,y) in game.legal_moves_for(color, (q,r))]
    return jsonify({'ok':True,'moves':moves})

@app.post('/api/legal_placements')
def api_legal_placements():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    spots = [{'q':x,'r':y} for (x,y) in game.legal_placement_spots(color)]
    return jsonify({'ok':True,'spots':spots})

@app.post('/api/place')
def api_place():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    p_abbr = (payload or {}).get('piece','').upper()
    if p_abbr not in ABBR_TO_TYPE:
        return ('Unknown piece. Use Q,B,S,G,A,L,M', 400)
    try:
        q = int((payload or {}).get('q'))
        r = int((payload or {}).get('r'))
    except Exception:
        return ('Invalid coordinates', 400)
    try:
        game.place(color, ABBR_TO_TYPE[p_abbr], (q,r))
        return jsonify({'ok':True,'state':game.state()})
    except Exception as e:
        return (str(e), 400)

@app.post('/api/move')
def api_move():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    try:
        fq = int((payload or {}).get('from_q'))
        fr = int((payload or {}).get('from_r'))
        tq = int((payload or {}).get('to_q'))
        tr = int((payload or {}).get('to_r'))
    except Exception:
        return ('Invalid coordinates', 400)
    try:
        game.move(color, (fq,fr), (tq,tr))
        return jsonify({'ok':True,'state':game.state()})
    except Exception as e:
        return (str(e), 400)

@app.post('/api/expansions')
def api_expansions():
    payload = request.get_json(force=True)
    playerId, err = require_player(payload)
    if err:
        return err
    code_color = PLAYERS.get(playerId)
    if not code_color:
        return ('You are not in a game. Start or Join first.', 400)
    code, color = code_color
    game = GAMES[code]
    flag = (payload or {}).get('flag','ON').upper()
    game.rules.use_expansions = (flag == 'ON')
    return jsonify({'ok':True,'flag':flag})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

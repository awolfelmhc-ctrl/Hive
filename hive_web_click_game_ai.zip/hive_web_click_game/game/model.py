
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional
from enum import Enum

Axial = Tuple[int, int]

class Color(str, Enum):
    WHITE = 'W'
    BLACK = 'B'

class PieceType(str, Enum):
    QUEEN = 'Q'
    BEETLE = 'B'
    SPIDER = 'S'
    GRASSHOPPER = 'G'
    ANT = 'A'
    LADYBUG = 'L'
    MOSQUITO = 'M'

@dataclass
class Piece:
    color: Color
    ptype: PieceType

@dataclass
class Cell:
    stack: List[Piece] = field(default_factory=list)

    def top(self) -> Optional[Piece]:
        return self.stack[-1] if self.stack else None

    def is_empty(self) -> bool:
        return len(self.stack) == 0

class Board:
    def __init__(self):
        self.cells: Dict[Axial, Cell] = {}

    def get(self, pos: Axial) -> Cell:
        return self.cells.setdefault(pos, Cell())

    def neighbors(self, pos: Axial) -> List[Axial]:
        q, r = pos
        dirs = [(1,0),(1,-1),(0,-1),(-1,0),(-1,1),(0,1)]
        return [(q+dq, r+dr) for dq, dr in dirs]

    def direction_index(self, from_pos: Axial, to_pos: Axial) -> Optional[int]:
        q1, r1 = from_pos
        q2, r2 = to_pos
        dq, dr = q2 - q1, r2 - r1
        dirs = [(1,0),(1,-1),(0,-1),(-1,0),(-1,1),(0,1)]
        try:
            return dirs.index((dq, dr))
        except ValueError:
            return None

    def occupied_positions(self) -> List[Axial]:
        return [pos for pos, cell in self.cells.items() if not cell.is_empty()]

    def remove_top(self, pos: Axial) -> Optional[Piece]:
        cell = self.get(pos)
        if cell.stack:
            return cell.stack.pop()
        return None

    def add_piece(self, pos: Axial, piece: Piece):
        self.get(pos).stack.append(piece)

    def is_top(self, pos: Axial, piece: Piece) -> bool:
        cell = self.get(pos)
        return cell.top() == piece


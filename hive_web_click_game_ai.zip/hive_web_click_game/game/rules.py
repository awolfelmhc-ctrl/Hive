
from typing import List, Set
from .model import Board, Piece, PieceType, Color, Axial

DIRS = [(1,0),(1,-1),(0,-1),(-1,0),(-1,1),(0,1)]

BASE_SET = {
    PieceType.QUEEN: 1,
    PieceType.BEETLE: 2,
    PieceType.SPIDER: 2,
    PieceType.GRASSHOPPER: 2,
    PieceType.ANT: 3,
}
EXPANSIONS = {
    PieceType.LADYBUG: 1,
    PieceType.MOSQUITO: 1,
}

class MoveError(Exception):
    pass

class Rules:
    def __init__(self, use_expansions: bool = True):
        self.use_expansions = use_expansions

    def initial_bag(self) -> dict:
        bag = dict(BASE_SET)
        if self.use_expansions:
            bag.update(EXPANSIONS)
        return bag

    def can_slide(self, board: Board, from_pos: Axial, to_pos: Axial) -> bool:
        i = board.direction_index(from_pos, to_pos)
        if i is None:
            return False
        q2, r2 = to_pos
        left = (q2 + DIRS[(i-1)%6][0], r2 + DIRS[(i-1)%6][1])
        right = (q2 + DIRS[(i+1)%6][0], r2 + DIRS[(i+1)%6][1])
        left_occ = not board.get(left).is_empty()
        right_occ = not board.get(right).is_empty()
        return not (left_occ and right_occ)

    def one_hive_after_move(self, board: Board, from_pos: Axial) -> bool:
        removed = board.remove_top(from_pos)
        try:
            occ = [pos for pos in board.cells.keys() if not board.get(pos).is_empty()]
            if not occ:
                return True
            visited = set()
            stack = [occ[0]]
            while stack:
                p = stack.pop()
                if p in visited:
                    continue
                visited.add(p)
                for n in board.neighbors(p):
                    if not board.get(n).is_empty():
                        stack.append(n)
            return len(visited) == len(occ)
        finally:
            if removed:
                board.add_piece(from_pos, removed)

    def is_top_piece(self, board: Board, pos: Axial, piece: Piece) -> bool:
        return board.is_top(pos, piece)

    def valid_destinations(self, board: Board, pos: Axial, piece: Piece) -> Set[Axial]:
        if piece.ptype == PieceType.QUEEN:
            return self._queen_moves(board, pos)
        if piece.ptype == PieceType.BEETLE:
            return self._beetle_moves(board, pos)
        if piece.ptype == PieceType.SPIDER:
            return self._spider_moves(board, pos)
        if piece.ptype == PieceType.GRASSHOPPER:
            return self._grasshopper_moves(board, pos)
        if piece.ptype == PieceType.ANT:
            return self._ant_moves(board, pos)
        if piece.ptype == PieceType.LADYBUG:
            return self._ladybug_moves(board, pos)
        if piece.ptype == PieceType.MOSQUITO:
            return self._mosquito_moves(board, pos)
        return set()

    def _ground_neighbors_empty(self, board: Board, pos: Axial) -> List[Axial]:
        return [n for n in board.neighbors(pos) if board.get(n).is_empty()]

    def _queen_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        return {n for n in self._ground_neighbors_empty(board, pos) if self.can_slide(board, pos, n)}

    def _beetle_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        return set(board.neighbors(pos))

    def _spider_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        results = set()
        def dfs(curr: Axial, depth: int, visited: set):
            if depth == 3:
                if curr != pos:
                    results.add(curr)
                return
            for n in self._ground_neighbors_empty(board, curr):
                if n in visited:
                    continue
                if self.can_slide(board, curr, n):
                    dfs(n, depth+1, visited | {n})
        dfs(pos, 0, {pos})
        return results

    def _grasshopper_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        dests = set()
        q, r = pos
        for dq, dr in DIRS:
            cq, cr = q + dq, r + dr
            jumped = 0
            while not board.get((cq, cr)).is_empty():
                jumped += 1
                cq += dq
                cr += dr
            if jumped >= 1:
                dests.add((cq, cr))
        return dests

    def _ant_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        frontier = [pos]
        visited = {pos}
        while frontier:
            curr = frontier.pop()
            for n in self._ground_neighbors_empty(board, curr):
                if n in visited:
                    continue
                if self.can_slide(board, curr, n):
                    visited.add(n)
                    frontier.append(n)
        visited.discard(pos)
        return visited

    def _ladybug_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        results = set()
        for s1 in board.neighbors(pos):
            if board.get(s1).is_empty():
                continue
            for s2 in board.neighbors(s1):
                if board.get(s2).is_empty():
                    continue
                for s3 in board.neighbors(s2):
                    if not board.get(s3).is_empty():
                        continue
                    results.add(s3)
        return results

    def _mosquito_moves(self, board: Board, pos: Axial) -> Set[Axial]:
        cell = board.get(pos)
        on_top = len(cell.stack) > 1 and cell.top().ptype == PieceType.MOSQUITO
        if on_top:
            return self._beetle_moves(board, pos)
        abilities = set()
        for n in board.neighbors(pos):
            t = board.get(n).top()
            if t:
                abilities.add(t.ptype)
        dests = set()
        for ptype in abilities:
            fake = Piece(color=cell.top().color if cell.top() else Color.WHITE, ptype=ptype)
            dests |= self.valid_destinations(board, pos, fake)
        return dests

    def queen_surrounded(self, board: Board, color: Color) -> bool:
        for pos, cell in board.cells.items():
            for p in cell.stack:
                if p.ptype == PieceType.QUEEN and p.color == color:
                    occupied = sum(1 for n in board.neighbors(pos) if not board.get(n).is_empty())
                    return occupied == 6
        return False


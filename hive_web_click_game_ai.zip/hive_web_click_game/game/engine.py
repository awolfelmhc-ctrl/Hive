
import random
import string
from typing import Optional, Tuple, List, Dict
from .model import Board, Piece, PieceType, Color, Axial
from .rules import Rules, MoveError

class Game:
    def __init__(self, expansions: bool = True):
        self.board = Board()
        self.rules = Rules(use_expansions=expansions)
        self.bags = {
            Color.WHITE: self.rules.initial_bag(),
            Color.BLACK: self.rules.initial_bag(),
        }
        self.players = {Color.WHITE: None, Color.BLACK: None}
        self.turn = Color.WHITE
        self.turn_count = {Color.WHITE: 0, Color.BLACK: 0}
        self.queen_placed = {Color.WHITE: False, Color.BLACK: False}
        self.status = 'SETUP'  # RUNNING/ENDED
        self.winner: Optional[Color] = None

    def assign_player(self, color: Color, identity: str):
        self.players[color] = identity

    def player_color(self, identity: str) -> Optional[Color]:
        for c, i in self.players.items():
            if i == identity:
                return c
        return None

    def other(self, color: Color) -> Color:
        return Color.BLACK if color == Color.WHITE else Color.WHITE

    def next_turn(self):
        self.turn = self.other(self.turn)

    def place(self, color: Color, ptype: PieceType, pos: Axial):
        if color != self.turn:
            raise MoveError('Not your turn')
        if self.bags[color].get(ptype, 0) <= 0:
            raise MoveError('No more of that piece left')
        if not self._valid_placement(color, pos):
            raise MoveError('Invalid placement position')
        self.board.add_piece(pos, Piece(color=color, ptype=ptype))
        self.bags[color][ptype] -= 1
        self.turn_count[color] += 1
        if ptype == PieceType.QUEEN:
            self.queen_placed[color] = True
        if self.turn_count[color] >= 4 and not self.queen_placed[color]:
            raise MoveError('You must place your Queen by your fourth turn')
        self.status = 'RUNNING'
        self._post_move_checks(color)
        self.next_turn()

    def move(self, color: Color, from_pos: Axial, to_pos: Axial):
        if color != self.turn:
            raise MoveError('Not your turn')
        cell = self.board.get(from_pos)
        if cell.is_empty():
            raise MoveError('No piece at source')
        piece = cell.top()
        if piece.color != color:
            raise MoveError('That top piece is not yours')
        if not self.rules.is_top_piece(self.board, from_pos, piece):
            raise MoveError('Only the top piece of a stack can move')
        if not self.rules.one_hive_after_move(self.board, from_pos):
            raise MoveError('Move would break the One Hive rule')
        valid = self.rules.valid_destinations(self.board, from_pos, piece)
        if to_pos not in valid:
            raise MoveError('Destination not legal for that piece')
        self.board.remove_top(from_pos)
        self.board.add_piece(to_pos, piece)
        self._post_move_checks(color)
        self.next_turn()

    def _post_move_checks(self, color: Color):
        if self.rules.queen_surrounded(self.board, self.other(color)):
            self.status = 'ENDED'
            self.winner = color
        if self.rules.queen_surrounded(self.board, color) and self.rules.queen_surrounded(self.board, self.other(color)):
            self.status = 'ENDED'
            self.winner = None

    def _valid_placement(self, color: Color, pos: Axial) -> bool:
        occ = self.board.occupied_positions()
        if not occ:
            return True
        adjacent_own = False
        adjacent_opponent = False
        for n in self.board.neighbors(pos):
            top = self.board.get(n).top()
            if top:
                if top.color == color:
                    adjacent_own = True
                else:
                    adjacent_opponent = True
        if adjacent_opponent:
            return False
        return adjacent_own

    def legal_moves_for(self, color: Color, pos: Axial) -> List[Axial]:
        cell = self.board.get(pos)
        if cell.is_empty():
            return []
        piece = cell.top()
        if piece.color != color:
            return []
        if color != self.turn:
            return []
        if not self.rules.one_hive_after_move(self.board, pos):
            return []
        return list(self.rules.valid_destinations(self.board, pos, piece))

    def legal_placement_spots(self, color: Color) -> List[Axial]:
        # Compute all empty cells adjacent to the hive that satisfy placement rule for 'color'
        occ = set(self.board.occupied_positions())
        if not occ:
            # First placement anywhere around origin neighborhood
            return [(0,0)]
        spots = set()
        for pos in occ:
            for n in self.board.neighbors(pos):
                if self.board.get(n).is_empty():
                    spots.add(n)
        legal = []
        for s in spots:
            if self._valid_placement(color, s):
                legal.append(s)
        return legal

    def state(self) -> Dict:
        cells = []
        for (q,r), cell in self.board.cells.items():
            if cell.stack:
                cells.append({
                    'q': q, 'r': r,
                    'stack': [{'color': p.color.value, 'ptype': p.ptype.value} for p in cell.stack]
                })
        return {
            'cells': cells,
            'turn': self.turn.value,
            'status': self.status,
            'winner': None if self.winner is None else self.winner.value
        }

    @staticmethod
    def new_code() -> str:
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(6))


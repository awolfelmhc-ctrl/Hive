
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict
import math
import random

from .model import PieceType, Color, Piece

@dataclass
class Action:
    kind: str  # 'move' or 'place'
    detail: dict

class HiveAI:
    def __init__(self, difficulty: str = 'medium'):
        self.level = difficulty.lower()  # 'easy' | 'medium' | 'hard'

    def choose_action(self, game, color: Color) -> Optional[Action]:
        """Return an Action or None if no legal action."""
        legal_actions = self.enumerate_actions(game, color)
        if not legal_actions:
            return None
        if self.level == 'easy':
            return random.choice(legal_actions)
        if self.level == 'medium':
            # one-ply greedy: pick best scoring resultant state
            scored = []
            for act in legal_actions:
                gcopy = self.copy_game(game)
                self.apply_action(gcopy, color, act)
                score = self.evaluate(gcopy, color)
                scored.append((score, act))
            scored.sort(key=lambda x: x[0], reverse=True)
            return scored[0][1]
        # hard: depth-2 minimax (AI -> opp -> AI evaluated)
        return self.minimax_action(game, color, depth=2)

    def minimax_action(self, game, color: Color, depth: int = 2) -> Action:
        best_score = -1e9
        best_act = None
        legal_actions = self.enumerate_actions(game, color)
        if not legal_actions:
            return random.choice(self.enumerate_actions(game, color)) if self.enumerate_actions(game, color) else None
        for act in legal_actions:
            g1 = self.copy_game(game)
            self.apply_action(g1, color, act)
            score = self.min_value(g1, self.opponent(color), depth-1, color)
            if score > best_score:
                best_score = score
                best_act = act
        return best_act or random.choice(legal_actions)

    def min_value(self, game, opp_color: Color, depth: int, max_player: Color) -> float:
        if game.status == 'ENDED' or depth == 0:
            return self.evaluate(game, max_player)
        legal = self.enumerate_actions(game, opp_color)
        if not legal:
            return self.evaluate(game, max_player)
        best = +1e9
        for act in legal:
            g2 = self.copy_game(game)
            self.apply_action(g2, opp_color, act)
            val = self.max_value(g2, max_player, depth-1)
            if val < best:
                best = val
        return best

    def max_value(self, game, color: Color, depth: int) -> float:
        if game.status == 'ENDED' or depth == 0:
            return self.evaluate(game, color)
        legal = self.enumerate_actions(game, color)
        if not legal:
            return self.evaluate(game, color)
        best = -1e9
        for act in legal:
            g2 = self.copy_game(game)
            self.apply_action(g2, color, act)
            val = self.min_value(g2, self.opponent(color), depth-1, color)
            if val > best:
                best = val
        return best

    def evaluate(self, game, color: Color) -> float:
        # Heuristic: queen safety, surround progress, mobility, adjacency pressure
        opp = self.opponent(color)
        # queen surrounded count approximation
        q_sur_ai = self._queen_surround_count(game, color)
        q_sur_opp = self._queen_surround_count(game, opp)
        mobility_ai = len(self._all_moves(game, color))
        mobility_opp = len(self._all_moves(game, opp))
        pressure = self._adjacent_to_queen(game, color)
        opp_pressure = self._adjacent_to_queen(game, opp)
        # small bonus for pieces on top (beetles/mosquito on stacks)
        top_adv = self._stacks_top_adv(game, color)
        top_opp = self._stacks_top_adv(game, opp)
        score = (
            3.0 * q_sur_opp - 3.0 * q_sur_ai +
            0.2 * (mobility_ai - mobility_opp) +
            0.8 * (pressure - opp_pressure) +
            0.3 * (top_adv - top_opp)
        )
        # prefer placing queen by turn 3 if not placed
        if not game.queen_placed[color] and game.turn_count[color] >= 3:
            score -= 2.0
        return score

    def _queen_surround_count(self, game, color: Color) -> int:
        # count occupied neighbors of queen
        for (q,r), cell in game.board.cells.items():
            for p in cell.stack:
                if p.ptype == PieceType.QUEEN and p.color == color:
                    return sum(1 for n in game.board.neighbors((q,r)) if not game.board.get(n).is_empty())
        return 0

    def _adjacent_to_queen(self, game, color: Color) -> int:
        opp = self.opponent(color)
        target = None
        for (q,r), cell in game.board.cells.items():
            for p in cell.stack:
                if p.ptype == PieceType.QUEEN and p.color == opp:
                    target = (q,r)
                    break
        if not target:
            return 0
        return sum(1 for n in game.board.neighbors(target) if (not game.board.get(n).is_empty()) and game.board.get(n).top().color == color)

    def _stacks_top_adv(self, game, color: Color) -> int:
        return sum(1 for cell in game.board.cells.values() if cell.stack and len(cell.stack)>1 and cell.top().color == color)

    def opponent(self, color: Color) -> Color:
        return Color.BLACK if color == Color.WHITE else Color.WHITE

    def enumerate_actions(self, game, color: Color) -> List[Action]:
        actions: List[Action] = []
        # placement actions (always allowed rules-wise; queen by 4th enforced by engine)
        spots = game.legal_placement_spots(color)
        for ptype, count in game.bags[color].items():
            if count <= 0:
                continue
            # prefer not placing beetle first unless needed, but keep generic
            for s in spots:
                actions.append(Action('place', {'ptype': ptype.value, 'q': s[0], 'r': s[1]}))
        # move actions (only if queen placed)
        # The engine enforces queen placed before movement; we'll still enumerate
        for (q,r), cell in game.board.cells.items():
            if cell.stack and cell.top().color == color:
                for dest in game.legal_moves_for(color, (q,r)):
                    actions.append(Action('move', {'from_q': q, 'from_r': r, 'to_q': dest[0], 'to_r': dest[1]}))
        return actions

    def copy_game(self, game):
        # lightweight deep copy sufficient for evaluation
        from .engine import Game
        g = Game(expansions=game.rules.use_expansions)
        # copy bags
        g.bags = {Color.WHITE: dict(game.bags[Color.WHITE]), Color.BLACK: dict(game.bags[Color.BLACK])}
        # copy players/turns
        g.players = {Color.WHITE: game.players[Color.WHITE], Color.BLACK: game.players[Color.BLACK]}
        g.turn = game.turn
        g.turn_count = {Color.WHITE: game.turn_count[Color.WHITE], Color.BLACK: game.turn_count[Color.BLACK]}
        g.queen_placed = {Color.WHITE: game.queen_placed[Color.WHITE], Color.BLACK: game.queen_placed[Color.BLACK]}
        g.status = game.status
        g.winner = game.winner
        # copy board
        for (q,r), cell in game.board.cells.items():
            if cell.stack:
                for p in cell.stack:
                    g.board.add_piece((q,r), Piece(color=p.color, ptype=p.ptype))
        return g

    def apply_action(self, game, color: Color, act: Action):
        from .model import PieceType
        if act.kind == 'place':
            ptype = PieceType(act.detail['ptype'])
            game.place(color, ptype, (act.detail['q'], act.detail['r']))
        else:
            game.move(color, (act.detail['from_q'], act.detail['from_r']), (act.detail['to_q'], act.detail['to_r']))
